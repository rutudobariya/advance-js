const emp='{"id":1001,"name":"brijesh","age":32}';
/* console.log(emp);
console.log(typeof(emp));
*/
const res=JSON.parse(emp);
// console.log(typeof(res));
// console.log(res);
const res1=JSON.stringify(res);  
// console.log(res1);
console.log(typeof(res1));
