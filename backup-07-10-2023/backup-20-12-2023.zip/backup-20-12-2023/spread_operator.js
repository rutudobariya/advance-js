/*  spread operator : is used to concatenate more tha two array or merge more than two array
 ... denoted by 
 */
const arr1=["fenish","fenil","femish"];
const arr2=["bhavika","rutu","bhavesh"];
console.log(...arr1,...arr2);
