const a=10;   //number
const b=parseInt("20"); //string 
const c=a+b;
console.log(c);