/* ternary operator is used to as conditional operator */
let ag=10;
let res=ag>=18?"elegible":"not eleigible";
console.log(res);

