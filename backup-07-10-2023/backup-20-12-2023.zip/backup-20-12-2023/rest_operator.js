/* rest operator   */
function nm(...args)    
{
   console.log(args);
}
nm();
nm("bhavesh");
nm(1,2,3,4,5,6);
nm("bhavesh",2);