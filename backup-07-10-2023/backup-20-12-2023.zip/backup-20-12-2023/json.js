/* json stands for javascript object notation
   json is used to stored data inside of {} object by literals | by new keyword | by constructor this keyword
   json is an formate that can be used to stored any api.
   api stands for application programming interface
      examples data.json 
 
*/

{
    "employee"=[
        {
            "id":1001,
            "name":"Brijesh",
            "age":32
        },

        {
            "id":1002,
            "name":"Keval",
            "age":32
        },

        {
            "id":1003,
            "name":"Kumar",
            "age":32
        },
    ]
}  